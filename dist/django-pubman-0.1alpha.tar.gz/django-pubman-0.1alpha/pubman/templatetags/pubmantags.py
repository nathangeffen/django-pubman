from django import template
#from django.template.defaultfilters import stringfilter
from django.utils.html import escape
from django.utils.safestring import mark_safe
from django.template.defaultfilters import urlize, linebreaks
from django.contrib.markup.templatetags.markup import markdown, restructuredtext

from pubman import settings 

register = template.Library()

@register.simple_tag
def format_content(value, format):

    
    if format=='M': # markdown
        value = markdown(value, settings.MARKDOWN_EXTENSIONS)
    elif format == 'R':
        value = restructuredtext(value) 
    elif format=='H':
        value = mark_safe(value)
    else:
        value = linebreaks(urlize(escape(value)))
            
    return value
    
format_content.needs_autoescape = True
