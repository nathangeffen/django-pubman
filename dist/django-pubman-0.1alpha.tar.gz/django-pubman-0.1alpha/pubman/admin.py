"""Implements customised admin screens for Publication Manager models.

    Mostly standard but two things users of pubman should be aware of:
        1. If a textarea is given the class "editor", then it is rendered on  
        the admin screen giving users a choice to switch between a tinymce editor,
        markdown editor or plain textarea editor. A text_format select box must 
        also be rendered on the same screen.
        2. Instead of limiting users for the users_who_can_edit_this fields in the
        model, it is done here by setting the kwargs["queryset"] value.
        
    This module could do with some refactoring.  
"""

#from django.contrib.comments import Comment
from django.contrib.comments.models import CommentFlag
from django import forms
from django.contrib import admin
from django.contrib.contenttypes import generic
from django.contrib.flatpages.admin import FlatPageAdmin
from django.contrib.flatpages.models import FlatPage
from django.contrib.auth.models import User
from django.utils.translation import ugettext as _

from sorl.thumbnail.admin import AdminImageMixin

from pubman.models import Copyright
from pubman.models import UserProfile
from pubman.models import Subscription
from pubman.models import MediaObject
from pubman.models import Credit
from pubman.models import OrderedCredit
from pubman.models import Article
from pubman.models import OutOfDate
from pubman.models import HistoricalEdit
from pubman.models import Translation
from pubman.models import FurtherReading
from pubman.models import Story
from pubman.models import OrderedArticle
from pubman.models import FeaturedStory 
from pubman.models import FeaturedWebpageGroup
from pubman.models import WebpageLink
from pubman.models import OrderedWebpage
from pubman.models import FeaturedRSSFeed
from pubman.utils import get_limit_user_choices_query, action_clone

module_css = {
    'screen': ('css/smoothness/jquery-ui-1.8.6.custom.css',
            'css/wordcount.css',
            'markitup/skins/markitup/style.css',
            'markitup/sets/markdown/style.css',),
} 



module_js = (
    'pubman/js/jquery-1.4.3.min.js',
    'pubman/js/jquery-ui-1.8.6.custom.min.js',
)

textareas_js = (
    'pubman/js/tiny_mce/tiny_mce.js',                
    'pubman/js/textareas.js',
    'pubman/markitup/jquery.markitup.js',
    'pubman/markitup/sets/markdown/set.js',        
)


class OrderedCreditInline(generic.GenericTabularInline):
    model = OrderedCredit
    raw_id_fields = ('author_or_institution',)
    extra = 1
    verbose_name = 'Credit' 
      

class MediaObjectForm(forms.ModelForm):
    model = MediaObject
    class Media:
        css = module_css        
        js = module_js 

class MediaObjectAdmin(AdminImageMixin, admin.ModelAdmin):
    form = MediaObjectForm
    list_display = ['id', 'title', 'thumbprint', 'full_author_list',  
                    'copyright', 'publication_stage',]
    list_filter = ('publication_stage', 'copyright', 'tags', 
                   'date_captured', 'date_published')
    list_editable = ('publication_stage',)
    search_fields = ('title', 'author__author_or_institution__first_names', 
                     'author__author_or_institution__last_name',)
    save_on_top = True
    prepopulated_fields = {"slug": ("title",)}
    filter_horizontal = ['users_who_can_edit_this',]    
    inlines = [OrderedCreditInline,]
    actions = [action_clone]

    fieldsets = (
        (None, {
            'classes': ['wide',],    
            'fields': ('title', 'subtitle', 
                       ('date_published',  
                        'publication_stage'),
                        )
        }),
        (_('Media'),
         {'fields': ('media_type','local_image' ,'local_video', 'external_location',),
        }),
        (_('Information about this media'),
         {'fields': ('caption','date_captured',),
        }),
        
        (_('Categorise this media by giving it tags'),
         {'fields': ('tags',),  }),
               
        (_('Advanced options'), {
            'classes': ['collapse',],                                 
            'fields': ('copyright',
                       'notes',
                       'users_who_can_edit_this', 
                       'slug',)
        }),
    )

    
    def formfield_for_manytomany(self, db_field, request, **kwargs): 
        if db_field.name == 'users_who_can_edit_this':
            kwargs["initial"]  = [request.user]
            kwargs["queryset"] = User.objects.filter(get_limit_user_choices_query("mediaobject"))            
        return super(MediaObjectAdmin, self).formfield_for_manytomany(db_field, request, **kwargs)

    def queryset(self, request):
        '''Limits to only those users who may edit this or be denied
        authorisation to edit this.
        '''
        qs = super(MediaObjectAdmin, self).queryset(request)
        if request.user.has_perm('pubman.edit_other_mediaobject'):
            return qs
        return qs.filter(users_who_can_edit_this__id=request.user.id)


class FurtherReadingInline(admin.TabularInline):
    model = FurtherReading    
    extra = 2

class ArticleForm(forms.ModelForm):      

    class Meta:
        model = Article

    class Media:
        css = module_css 
        js = module_js +  textareas_js 
    

class ArticleAdmin(admin.ModelAdmin):
    form = ArticleForm
    list_display = ['id', '__unicode__', 'full_author_list', 'date_last_edited', 
                    'date_published', 'publication_stage']
    list_editable = ['publication_stage',]
    list_filter = ['publication_stage', 'tags',
                   'date_published', 'date_last_edited']
    raw_id_fields = ('primary_media_object',)
    search_fields = ('title', 'author__author_or_institution__first_names', 
                     'author__author_or_institution__last_name')
    inlines = [OrderedCreditInline, FurtherReadingInline]
    prepopulated_fields = {"slug": ("title",)}
    filter_horizontal = ['users_who_can_edit_this',]    
    save_on_top = True
    actions = [action_clone]
    
    fieldsets = (
        (None, {
            'classes': ['wide',],    
            'fields': ('title', 'subtitle', 
                       ('date_published', 
                        'date_originally_published', 
                        'purpose_of_edit',
                        'publication_stage'),
                        )
        }),
        (_('Primary image or video'),
        {
         'fields': ('primary_media_object','override_caption',),
        }),
        (_('Content'),
         {'classes': ['editor',],
          'fields': ('blurb','article_text',),
        }),
        (_('Categorise this article by giving it tags'),
         {'fields': ('tags',),
        }),        
        (None, {'fields': ('text_format', 'primary_pullout_quote',)}),
        (_('Advanced options'), {
            'classes': ['collapse',],
            'fields': ('frontpage',
                       'page_break_strategy',
                       'language',
                       'complexity',
                       'subscription_required',
                       'copyright',
                       'notes',
                       'users_who_can_edit_this', 
                       'slug',)
        }),
    )
                


    def formfield_for_manytomany(self, db_field, request, **kwargs): 
        if db_field.name == 'users_who_can_edit_this':
            kwargs["initial"]  = [request.user]
            kwargs["queryset"] = User.objects.filter(get_limit_user_choices_query("article"))             
        return super(ArticleAdmin, self).formfield_for_manytomany(db_field, request, **kwargs)
    
    def queryset(self, request):
        '''Limits to only those users who may edit this or be denied
        authorisation to edit this.
        '''
        qs = super(ArticleAdmin, self).queryset(request)
        if request.user.has_perm('pubman.edit_other_article'):
            return qs
        return qs.filter(users_who_can_edit_this__id=request.user.id)


class TranslationForm(forms.ModelForm):
    model = Translation
    class Media:
        css = module_css
        js = module_js +  textareas_js 
    

class TranslationAdmin(admin.ModelAdmin):
    form = TranslationForm
    inlines = [OrderedCreditInline,]
    list_display = ['id', '__unicode__', 'full_author_list', 'date_last_edited', 
                    'date_published', 'publication_stage']
    list_filter = ['publication_stage', 'language',]
    list_editable = ['publication_stage',]    
    raw_id_fields = ('article',)
    search_fields = ('title', 'author__author_or_institution__first_names', 
                     'author__author_or_institution__last_name')    
    prepopulated_fields = {"slug": ("title",)}
    filter_horizontal = ['users_who_can_edit_this',]    
    save_on_top = True
    
    fieldsets = (
        (None, {
            'classes': ['wide',],    
            'fields': ('title', 'subtitle', 
                       ('date_published', 
                        'publication_stage'),
                        )
        }),
        (_('Article to which this translation is linked and the language of this translation'),
        {
         'fields': ('article', 'language',),
        }),
        (_('Content in the original article that can be translated'),
         {'classes': ['editor',],
          'fields': ('primary_media_object_caption', 'blurb','article_text','primary_pullout_quote',),
        }),
        (_('Categorise this article by giving it tags'),
         {'fields': ('tags',),
        }),        
        (None, {'fields': ('text_format',)}),
        ('Advanced options', {
            'classes': ['collapse',],
            'fields': ('copyright',
                        'notes',
                       'users_who_can_edit_this', 
                       'slug',)
        }),
    )
                
    def formfield_for_manytomany(self, db_field, request, **kwargs): 
        if db_field.name == 'users_who_can_edit_this':
            kwargs["initial"]  = [request.user]
            kwargs["queryset"] = User.objects.filter(get_limit_user_choices_query("translation"))             
        return super(TranslationAdmin, self).formfield_for_manytomany(db_field, request, **kwargs)
    
    def queryset(self, request):
        '''Limits to only those users who may edit this or be denied
        authorisation to edit this.
        '''
        qs = super(TranslationAdmin, self).queryset(request)
        if request.user.has_perm('pubman.edit_other_translation'):
            return qs
        return qs.filter(users_who_can_edit_this__id=request.user.id)




class OrderedArticleInline(admin.TabularInline):
    model = OrderedArticle
    raw_id_fields = ('article',)    

class StoryForm(forms.ModelForm):
    model = Story
    class Media:
        css = module_css
        js = module_js + textareas_js

class StoryAdmin(admin.ModelAdmin):
    form = StoryForm
    save_on_top = True
    inlines = [OrderedCreditInline, OrderedArticleInline, ] 
    filter_horizontal = ['users_who_can_edit_this',]
    actions = [action_clone]        
    prepopulated_fields = {"slug": ("title",)}
    list_display = ['id', '__unicode__', 'full_author_list', 'date_last_edited', 
                    'date_published', 'publication_stage']
    list_editable = ['publication_stage',]
    list_filter = ['publication_stage', 'tags',
                   'date_published', 'date_last_edited']
    raw_id_fields = ('primary_media_object',)
    search_fields = ('title', 'author__author_or_institution__first_names', 
                     'author__author_or_institution__last_name')
        

    fieldsets = (
        (None, {
            'classes': ['wide',],    
            'fields': ('title', 'subtitle', 
                       ('date_published',  
                        'publication_stage'),
                        )
        }),
        (_('Primary image or video'),
        {
         'fields': ('primary_media_object',),
        }),
        (_('Content'),
         {'classes': ['editor',],
          'fields': ('blurb','text_format',),
        }),
        (_('How the story will be presented'),
         {'fields': ('display_editors','number_of_articles_per_page',
                     'contents_as_ordered_list')}
        ),
        (_('Categorise this story by giving it tags'),
         {'fields': ('tags',),
        }),        
        (_('Advanced options'), {
            'classes': ['collapse',],
            'fields': ( 'copyright',
                        'notes',
                       'users_who_can_edit_this', 
                       'slug',)
        }),
    )


    def formfield_for_manytomany(self, db_field, request, **kwargs): 
        if db_field.name == 'users_who_can_edit_this':
            kwargs["initial"]  = [request.user]
            kwargs["queryset"] = User.objects.filter(get_limit_user_choices_query("mediaobject"))                                 
        return super(StoryAdmin, self).formfield_for_manytomany(db_field, request, **kwargs)

    def queryset(self, request):
        '''Limits to only those users who may edit this or be denied
        authorisation to edit this.
        '''
        qs = super(StoryAdmin, self).queryset(request)
        if request.user.has_perm('pubman.edit_other_story'):
            return qs
        return qs.filter(users_who_can_edit_this__id=request.user.id)
    

class CreditAdmin(admin.ModelAdmin):
    list_display = ['id', 'first_names', 'last_name', 'is_person',]
    list_editable =  ['first_names', 'last_name', 'is_person',]
    search_fields = ('first_names', 'last_name',)
    list_filter = ('is_person',)    

class OrderedArticleAdmin(admin.ModelAdmin):
    list_display = ['id', 'story', 'article','order']
    list_editable = ['article', 'order']
    search_fields = ['story__title', 'article__title']
    list_filter = ['story', ]
    raw_id_fields = ('story', 'article',)    

class FeaturedStoryAdmin(admin.ModelAdmin):
    list_display = ['id', 'story', 'featured','order', ]
    list_editable = ['featured', 'order']
    search_fields = ['story__title', 'story__orderedarticle__article__title']
    raw_id_fields = ('story',)    


class CommentAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'submit_date', 'ip_address', 'is_public', 'is_removed']
    list_filter = ['is_public', 'is_removed']
    list_editable = ['is_public', 'is_removed']
    date_hierarchy = 'submit_date'    
    ordering = ['-submit_date']
    search_fields = ['^user__username', '^user__first_name', '^user__last_name','ip_address', 'comment']


class FeaturedWebpageGroupForm(forms.ModelForm):
    model = FeaturedWebpageGroup
    class Media:
        css = module_css
        js = module_js + textareas_js


class OrderedWebpageInline(admin.TabularInline):
    model = OrderedWebpage
    raw_id_fields = ['webpage',]

class FeaturedWebpageGroupAdmin(admin.ModelAdmin):
    form = FeaturedWebpageGroupForm 
    list_display = ['id', 'title', 'order', 'featured',]
    list_editable = ['featured',]
    list_filter = ['featured',]
    inlines = [OrderedWebpageInline,]

class FeaturedWebpageGroupLink(admin.ModelAdmin):
    raw_id_fields = ['media_object',]

class FeaturedRSSFeedAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'order', 'featured',]
    list_editable = ['featured',]
    list_filter = ['featured',]


class FlatPageForm(forms.ModelForm):
    model = FlatPage
    class Media:
        css = module_css
        js = module_js + ('pubman/js/tiny_mce/tiny_mce.js',
                          'pubman/js/flatpagetextarea.js',)
    
class CustomFlatPageAdmin(FlatPageAdmin):
    form = FlatPageForm    
     

admin.site.register(Copyright)
admin.site.register(MediaObject, MediaObjectAdmin)
admin.site.register(Article, ArticleAdmin)
admin.site.register(OutOfDate)
admin.site.register(HistoricalEdit)
admin.site.register(Translation, TranslationAdmin)
admin.site.register(FurtherReading)
admin.site.register(Story, StoryAdmin)
admin.site.register(OrderedArticle, OrderedArticleAdmin)
admin.site.register(FeaturedStory, FeaturedStoryAdmin)
admin.site.register(Credit, CreditAdmin)
admin.site.register(OrderedCredit)
admin.site.register(CommentFlag)
admin.site.register(UserProfile)
admin.site.register(Subscription)
admin.site.register(FeaturedWebpageGroup, FeaturedWebpageGroupAdmin)
admin.site.register(WebpageLink)
admin.site.register(OrderedWebpage)
admin.site.register(FeaturedRSSFeed, FeaturedRSSFeedAdmin)

admin.site.unregister(FlatPage)
admin.site.register(FlatPage, CustomFlatPageAdmin)


