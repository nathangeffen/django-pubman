<?php

define(IBEGIN_SHARE_TABLE_PREFIX, 'ibs_');

$db = array(
    'username'  => 'ibs_stats',
    'password'  => 'ibs_stats',
    'host'      => '127.0.0.1',
    'port'      => '',
    'database'  => 'wordpress25',
    'type'      => 'mysql', // or postgresql
);

?>
