from distutils.core import setup

setup(
    name='django-pubman',
    version='0.1alpha',
    description='A simple content management system for Django.',
    author='Nathan Geffen',
    author_email='nathangeffen@gmail.com',
    url='http://gitorious.org/django-pubman',    
    packages=['pubman',],
    license='MIT',
    long_description=open('README').read(),
)
